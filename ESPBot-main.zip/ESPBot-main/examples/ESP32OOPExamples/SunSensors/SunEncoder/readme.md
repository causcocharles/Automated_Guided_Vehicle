ESP32下可以使用两个第三方库：
Encoder:https://github.com/PaulStoffregen/Encoder
ESP32Encoder:
支持ESP32 S3 请安装最新版本
或者使用自主开发的库
