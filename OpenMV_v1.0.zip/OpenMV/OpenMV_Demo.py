# 色块监测 例子
#
# 这个例子展示了如何通过find_blobs()函数来查找图像中的色块
# 这个例子查找的颜色是深绿色

import sensor, image, time

# 颜色追踪的例子，一定要控制环境的光，保持光线是稳定的。
green_threshold   = (0, 88, -64, -36, -76, 69)
blue_threshold   = (22, 64, -35, 25, -76, -25)
#(21, 65, -35, 25, -72, -25)Aa
red_threshold   = (22, 50, 22, 80, -30, 60)
#设置绿色的阈值，括号里面的数值分别是L A B 的最大值和最小值（minL, maxL, minA,
# maxA, minB, maxB），LAB的值在图像左侧三个坐标图中选取。如果是灰度图，则只需
#设置（min, max）两个数字即可。

sensor.reset() # 初始化摄像头
sensor.set_pixformat(sensor.RGB565) # 格式为 RGB565.
sensor.set_framesize(sensor.QVGA) # 使用 QQVGA 速度快一些
sensor.skip_frames(time = 2000) # 跳过2000s，使新设置生效,并自动调节白平衡
sensor.set_auto_gain(False) # 关闭自动自动增益。默认开启的，在颜色识别中，一定要关闭白平衡。
sensor.set_auto_whitebal(False)
#关闭白平衡。白平衡是默认开启的，在颜色识别中，一定要关闭白平衡。
clock = time.clock() # 追踪帧率
tar1_S = 0
tar2_S = 0


while(True):
    clock.tick()
    img = sensor.snapshot()

    blobs_red = img.find_blobs([red_threshold])
    if blobs_red:
        tar1_S = (blobs_red[0]).h() * (blobs_red[0]).w()
        tar1_b = blobs_red[0]
        tar2_S = 0
        for b_r in blobs_red[1:]:
            S = b_r.h() * b_r.w()
            if S > tar2_S:
                if S > tar1_S:
                    tar2_S = tar1_S
                    tar2_b = tar1_b
                    tar1_S = S
                    tar1_b = b_r
                elif S > tar2_S:
                    tar2_S = S
                    tar2_b = b_r
        if tar1_b.cy() > tar2_b.cy():
            red_up = tar1_b
            red_down = tar2_b
        else:
            red_up = tar2_b
            red_down = tar1_b
        img.draw_rectangle(red_up[0:4],color=(255,0,0)) # rect
        img.draw_cross(red_up[5], red_up[6]) # cx, cy
        img.draw_rectangle(red_down[0:4],color=(255,0,0)) # rect

    blobs_green = img.find_blobs([green_threshold])
    if blobs_green:
        tar1_S = tar2_S = (blobs_green[0]).h() * (blobs_green[0]).w()
        tar1_b = blobs_green[0]
        tar2_S = 0
        for b_g in blobs_green[1:]:
            S = b_g.h() * b_g.w()
            if S > tar2_S:
                if S > tar1_S:
                    tar2_S = tar1_S
                    tar2_b = tar1_b
                    tar1_S = S
                    tar1_b = b_g
                elif S > tar2_S:
                    tar2_S = S
                    tar2_b = b_g
        if tar1_b.cy() > tar2_b.cy():
            green_up = tar1_b
            green_down = tar2_b
        else:
            green_up = tar2_b
            green_down = tar1_b
        img.draw_rectangle(green_up[0:4],color=(0,255,0)) # rect
        img.draw_cross(green_up[5], green_up[6]) # cx, cy
        img.draw_rectangle(green_down[0:4],color=(0,255,0)) # rect

    blobs_blue = img.find_blobs([blue_threshold])
    if blobs_blue:
        tar1_S = tar2_S = (blobs_blue[0]).h() * (blobs_blue[0]).w()
        tar1_b = blobs_blue[0]
        tar2_S = 0
        for b_b in blobs_blue[1:]:
            S = b_b.h() * b_b.w()
            if S > tar2_S:
                if S > tar1_S:
                    tar2_S = tar1_S
                    tar2_b = tar1_b
                    tar1_S = S
                    tar1_b = b_b
                elif S > tar2_S:
                    tar2_S = S
                    tar2_b = b_b
        if tar1_b.cy() > tar2_b.cy():
            blue_up = tar1_b
            blue_down = tar2_b
        else:
            blue_up = tar2_b
            blue_down = tar1_b
        img.draw_rectangle(blue_up[0:4],color=(0,0,255)) # rect
        img.draw_cross(blue_up[5], blue_up[6]) # cx, cy
        img.draw_rectangle(blue_down[0:4],color=(0,0,255)) # rect

