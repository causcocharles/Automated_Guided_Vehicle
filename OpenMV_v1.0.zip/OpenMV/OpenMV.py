import sensor, image, time, json
from pyb import UART

green_threshold   = (0, 88, -64, -36, -76, 69)
blue_threshold   = (22, 64, -35, 25, -76, -25)
red_threshold   = (22, 50, 22, 80, -30, 60)

sensor.reset()
sensor.set_vflip(True)              # 上下翻转:开
sensor.set_hmirror(True)              # 左右翻转:开
sensor.set_pixformat(sensor.RGB565) # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)   # Set frame size to QVGA (320x240)
sensor.skip_frames(time = 2000)
sensor.set_auto_gain(False)         # 自动增益:关
sensor.set_auto_whitebal(False)          # 白平衡:关
sensor.set_auto_exposure(False)     # 自动曝光: 关

# Wait for settings take effect.
clock = time.clock()                # Create a clock object to track the FPS.
i = 1
tar1_S = 0
tar2_S = 0
color_count = 0
send_position_flag = 1
red_flag = 0
green_flag = 0
blue_flag = 0

while(True):
    clock.tick()
    uart = UART(3, 115200)
    img = sensor.snapshot()         # Take a picture and return the image.
    img.lens_corr(1.8) # strength of 1.8 is good for the 2.8mm lens.
    for code in img.find_qrcodes():
        if(i == 1):
            uart.write(code.payload())
            print(code.payload())
            i = 0
        else:
            print("Codes had been sent!")
    if(uart.any()):
        blobs_red = img.find_blobs([red_threshold])
        if len(blobs_red)>=2:
            red_flag = 1
            tar1_S = (blobs_red[0]).h() * (blobs_red[0]).w()
            tar1_b = blobs_red[0]
            tar2_S = 0
            for b_r in blobs_red[1:]:
                S = b_r.h() * b_r.w()
                if S > tar2_S:
                    if S > tar1_S:
                        tar2_S = tar1_S
                        tar2_b = tar1_b
                        tar1_S = S
                        tar1_b = b_r
                    elif S > tar2_S:
                        tar2_S = S
                        tar2_b = b_r
            if tar1_b.cy() < tar2_b.cy():
                red_up = tar1_b
                red_down = tar2_b
            else:
                red_up = tar2_b
                red_down = tar1_b
            img.draw_rectangle(red_up[0:4],color=(255,0,0)) # rect
            img.draw_cross(red_up[5], red_up[6]) # cx, cy
            img.draw_rectangle(red_down[0:4],color=(255,0,0)) # rect

        blobs_green = img.find_blobs([green_threshold])
        if len(blobs_green)>=2:
            green_flag = 1
            tar1_S = tar2_S = (blobs_green[0]).h() * (blobs_green[0]).w()
            tar1_b = blobs_green[0]
            tar2_S = 0
            for b_g in blobs_green[1:]:
                S = b_g.h() * b_g.w()
                if S > tar2_S:
                    if S > tar1_S:
                        tar2_S = tar1_S
                        tar2_b = tar1_b
                        tar1_S = S
                        tar1_b = b_g
                    elif S > tar2_S:
                        tar2_S = S
                        tar2_b = b_g
            if tar1_b.cy() < tar2_b.cy():
                green_up = tar1_b
                green_down = tar2_b
            else:
                green_up = tar2_b
                green_down = tar1_b
            img.draw_rectangle(green_up[0:4],color=(0,255,0)) # rect
            img.draw_cross(green_up[5], green_up[6]) # cx, cy
            img.draw_rectangle(green_down[0:4],color=(0,255,0)) # rect

        blobs_blue = img.find_blobs([blue_threshold])
        if len(blobs_blue)>=2:
            blue_flag = 1
            tar1_S = tar2_S = (blobs_blue[0]).h() * (blobs_blue[0]).w()
            tar1_b = blobs_blue[0]
            tar2_S = 0
            for b_b in blobs_blue[1:]:
                S = b_b.h() * b_b.w()
                if S > tar2_S:
                    if S > tar1_S:
                        tar2_S = tar1_S
                        tar2_b = tar1_b
                        tar1_S = S
                        tar1_b = b_b
                    elif S > tar2_S:
                        tar2_S = S
                        tar2_b = b_b
            if tar1_b.cy() < tar2_b.cy():
                blue_up = tar1_b
                blue_down = tar2_b
            else:
                blue_up = tar2_b
                blue_down = tar1_b
            img.draw_rectangle(blue_up[0:4],color=(0,0,255)) # rect
            img.draw_cross(blue_up[5], blue_up[6]) # cx, cy
            img.draw_rectangle(blue_down[0:4],color=(0,0,255)) # rect
        str_position = ""
        if(red_up.x() < green_up.x() and green_up.x() < blue_up.x()):
            str_position = str_position + "x123+"
        elif(red_up.x() < blue_up.x() and blue_up.x() < green_up.x()):
            str_position = str_position + "x132+"

        elif(green_up.x() < red_up.x() and red_up.x() < blue_up.x()):
            str_position = str_position + "x213+"

        elif(green_up.x() < blue_up.x() and blue_up.x() < red_up.x()):
            str_position = str_position + "x231+"

        elif(blue_up.x() < red_up.x() and red_up.x() < green_up.x()):
            str_position = str_position + "x312+"

        else:
            str_position = str_position + "x321+"

        if(red_down.x() < green_down.x() and green_down.x() < blue_down.x()):
            str_position = str_position + "x123+"

        elif(red_down.x() < blue_down.x() and blue_down.x() < green_down.x()):
            str_position = str_position + "x132+"

        elif(green_down.x() < red_down.x() and red_down.x() < blue_down.x()):
            str_position = str_position + "x213+"

        elif(green_down.x() < blue_down.x() and blue_down.x() < red_down.x()):
            str_position = str_position + "x231+"

        elif(blue_down.x() < red_down.x() and red_down.x() < green_down.x()):
            str_position = str_position + "x312+"

        else:
            str_position = str_position + "x321"
        if blue_flag == 1 && red_flag == 1 && green_flag == 1:
            if(send_position_flag):
                uart.write(str_position)
                print(str_position)
                send_position_flag = 0
            else:
                print("position had been sent!")



