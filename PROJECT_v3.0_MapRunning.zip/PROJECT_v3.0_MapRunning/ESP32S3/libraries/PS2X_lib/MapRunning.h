int n = 0, waitcount;
void MapRunning(void){
    if(n = 0){

    }
}